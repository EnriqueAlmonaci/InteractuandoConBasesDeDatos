var Usuario = require('./modelUsuarios.js')

module.exports.crearUsuarioDemo = function(callback){
  var arr = [{ email: 'jose@mail.com', user: "jose", password: "jose123"}];
  Usuario.insertMany(arr, function(error, docs) {
    if (error){
      if (error.code == 11000){
        callback("Utilice los siguientes datos: </br>usuario: jose | password:jose123")
      }else{
        callback(error.message)
      }
    }else{
      callback(null, "El usuario jose se ha registrado correctamente. </br>usuario: jose | password:jose123 ") 
    }
  });
}
