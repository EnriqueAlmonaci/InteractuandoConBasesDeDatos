<?php
require('conexion.php');

session_start();

  if (isset($_SESSION['ID']))
  {

    $con = new ConectorBD();

    if ($con->initConexion('agenda')=='OK'){
      if ($con->eliminarRegistro('tbleventos','ID_Evento = '.$_POST['id']))
      {
        $response['msg'] = 'OK';
      }
      else {
        $response['msg'] = 'Error al eliminar el evento';
      }



    }
    else {
        $response['msg'] = 'Problemas con la conexión';
    }


  }
  else {
    $response['msg'] = 'Debe iniciar Sesión';
  }

echo json_encode($response);

 ?>
