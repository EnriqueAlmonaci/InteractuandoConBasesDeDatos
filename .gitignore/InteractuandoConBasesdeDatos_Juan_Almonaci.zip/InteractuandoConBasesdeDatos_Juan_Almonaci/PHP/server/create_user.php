<?php

require('Conexion.php');

$data = file_get_contents("Usuarios.json");

$usuarios = json_decode(($data));

foreach($usuarios->usuarios as $usuario)
{
    $datos['Usuario'] = $usuario->Usuario;
    $datos['Nombre'] = $usuario->Nombre;
    $datos['Password'] = password_hash($usuario->Password, PASSWORD_DEFAULT);
    $datos['Fecha_Nacimiento'] =$usuario->Fecha_Nacimiento;


    $con = new ConectorBD();


    if ($con->initConexion('agenda')=='OK'){
      if($con->insertData("tblusuarios", $datos)){
        echo"exito en la inserción";
      }else {
      echo"Hubo en error y los datos no han sido guardados";
      $con->cerrarConexion();
    }
    }
    else {
      echo"No se pudo conectar a la Base de Datos";
    }
}

//echo json_encode($response);
 ?>
