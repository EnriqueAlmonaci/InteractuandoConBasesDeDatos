<?php
require('conexion.php');

session_start();

  if (isset($_SESSION['ID']))
  {

    $con = new ConectorBD();

    if ($con->initConexion('agenda')=='OK'){
      $datos['Fecha_Inicio'] = $_POST['start_date'];
			$datos['Hora_Inicio'] = $_POST['start_hour'];
			$datos['Fecha_Fin'] = $_POST['end_date'];
			$datos['Hora_Fin'] = $_POST['end_hour'];


      if ($con->actualizarRegistro('tbleventos',$datos,'Id_Evento ='.$_POST['id']))
      {
        $response['msg'] = 'OK';
      }
      else {
        $response['msg'] = 'Error al actualizar el evento';
      }


    }
    else {

    $response['msg'] = 'Error de conexión';
    }

  }
  else {
    $response['msg'] = 'Debe iniciar sesión';
  }

echo json_encode($response);

 ?>
