<?php

require('Conexion.php');

$username = $_POST["username"];
$password = $_POST["password"];
//$username = "enriquealmonaci@hotmail.com";
//$password = "Miagenda123";
//session_start();
//$_SESSION["ID_Usuario"]="";

$con = new ConectorBD();

if ($con->initConexion('agenda')=='OK'){
  if($resultado_consulta = $con->consultar(['tblusuarios'], ['ID','Password'],'WHERE Usuario="'.$username.'"'))
  {
    $fila = $resultado_consulta->fetch_assoc();
    if(password_verify($password,$fila['Password']))
    {
      session_start();
      $_SESSION['ID']=$fila['ID'];
      $response['msg']='OK';
    }
    else {
      $response['msg']='Credenciales incorrectas, intente de nuevo';

    }
  }
  else {
    $response['msg']='Error en la consulta';

  }
}


echo json_encode($response);

$con->cerrarConexion();

 ?>
