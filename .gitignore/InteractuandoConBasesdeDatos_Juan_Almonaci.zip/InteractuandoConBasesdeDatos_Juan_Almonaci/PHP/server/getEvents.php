<?php

require('conexion.php');

session_start();

  if (isset($_SESSION['ID']))
  {
    $con = new ConectorBD();

    if ($con->initConexion('agenda')=='OK'){
      if($resultado_consulta = $con->consultar(['tbleventos'], ['*'],"WHERE ID_Usuario='".$_SESSION['ID']."'"))
      {
        //$fila = $resultado_consulta->fetch_assoc();
        $i = 0;
        while($fila = $resultado_consulta->fetch_assoc()){
        $evento['id']=$fila['ID_Evento'];
        $evento['title']=$fila['Evento'];
        if($fila['Dia_Completo']==1){
          $evento['start']=$fila['Fecha_Inicio'];
          $evento['allday']=true;
        }
        else {
          $evento['start']=$fila['Fecha_Inicio'].'T'.$fila['Hora_Inicio'];
          $evento['end']=$fila['Fecha_Fin'].'T'.$fila['Hora_Fin'];
          $evento['allday']=false;
        }

        $evento['color'] = '#' . substr(str_shuffle('ABCDEF0123456789'), 0, 6);
        $response['eventos'][$i] = $evento;
        $i++;
      }

        $response['msg'] = "OK";

      }
      else {
        $response['msg'] = "Error en la consulta";
      }
    }else {
        $response['msg'] = "No se pudo conectar a la Base de Datos";
    }

  }
  else {
      $response['msg'] = "No se ha iniciado una sesión";
  }

  echo json_encode($response);

 ?>
