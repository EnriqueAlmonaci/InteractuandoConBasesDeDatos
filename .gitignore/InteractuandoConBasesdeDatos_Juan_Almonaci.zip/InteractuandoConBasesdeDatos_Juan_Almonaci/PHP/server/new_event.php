<?php

require('conexion.php');

session_start();

  if (isset($_SESSION['ID']))
  {
    $con = new ConectorBD();

    if ($con->initConexion('agenda')=='OK'){

      $datos['ID_Usuario'] = $_SESSION['ID'];
      $datos['Evento'] = $_POST['titulo'];
      $datos['Fecha_Inicio'] = $_POST['start_date'];

      if ($_POST['allDay']=='true')
      {
        $datos['Dia_Completo'] = 1;
      }
      else {
        $datos['Dia_Completo'] = 0;
        $datos['Hora_Inicio'] = $_POST['start_hour'];
        $datos['Fecha_Fin'] = $_POST['end_date'];
        $datos['Hora_Fin'] = $_POST['end_hour'];
      }

      if($con->insertData("tbleventos",$datos))
      {
        $response['msg'] = 'OK';
      }
      else {
        $response['msg'] = 'No se ha podido guardar el evento';
      }

    }
    else {
        $response['msg'] = 'Problemas con la conexión';
    }
}
else {
    $response['msg'] = 'Debe iniciar sesión';
}

echo json_encode($response);

 ?>
