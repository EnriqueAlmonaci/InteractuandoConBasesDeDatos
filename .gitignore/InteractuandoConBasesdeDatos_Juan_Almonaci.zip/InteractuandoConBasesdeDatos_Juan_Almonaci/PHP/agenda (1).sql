-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2018 at 11:51 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agenda`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbleventos`
--

CREATE TABLE `tbleventos` (
  `ID_Usuario` int(11) NOT NULL,
  `ID_Evento` int(11) NOT NULL,
  `Evento` varchar(250) NOT NULL,
  `Fecha_Inicio` date NOT NULL,
  `Hora_Inicio` time DEFAULT NULL,
  `Fecha_Fin` date DEFAULT NULL,
  `Hora_Fin` time DEFAULT NULL,
  `Dia_Completo` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbleventos`
--

INSERT INTO `tbleventos` (`ID_Usuario`, `ID_Evento`, `Evento`, `Fecha_Inicio`, `Hora_Inicio`, `Fecha_Fin`, `Hora_Fin`, `Dia_Completo`) VALUES
(2, 20, 'DÃ­a de la madre', '2018-05-15', '00:00:00', '0000-00-00', '00:00:00', 1),
(2, 21, 'dia del trabajo', '2018-05-01', NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblusuarios`
--

CREATE TABLE `tblusuarios` (
  `ID` int(11) NOT NULL,
  `Usuario` varchar(250) NOT NULL,
  `Nombre` varchar(250) NOT NULL,
  `Password` varchar(250) NOT NULL,
  `Fecha_Nacimiento` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusuarios`
--

INSERT INTO `tblusuarios` (`ID`, `Usuario`, `Nombre`, `Password`, `Fecha_Nacimiento`) VALUES
(2, 'enriquealmonaci@hotmail.com', 'Juan Enrique Almonaci Valadez', '$2y$10$WOviNCYzYAw1ns47eKw.GuFiqlcaQX/JNUwP/Ej1ZVsmq/OuvtBDi', '1982-06-23'),
(3, 'sergiofonseca@hotmail.com', 'Sergio fonseca Balandran', '$2y$10$s/ioBORaecdaqggwPtPy8uhW9zAkHKIZMW0Ss1Py2D8xXRZMA7b5i', '1980-07-04'),
(4, 'miguelangellopez@hotmail.com', 'Miguel Angel Lopez Anguiano', '$2y$10$lyeIBSeOxJPpZqj5TCsIZOgg.Fv2lCNsNwfSt.U9AN5.Pe4mT5xYW', '1978-06-28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbleventos`
--
ALTER TABLE `tbleventos`
  ADD PRIMARY KEY (`ID_Evento`),
  ADD UNIQUE KEY `Index_Eventos` (`ID_Usuario`,`ID_Evento`);

--
-- Indexes for table `tblusuarios`
--
ALTER TABLE `tblusuarios`
  ADD UNIQUE KEY `Index_ID` (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbleventos`
--
ALTER TABLE `tbleventos`
  MODIFY `ID_Evento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblusuarios`
--
ALTER TABLE `tblusuarios`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
